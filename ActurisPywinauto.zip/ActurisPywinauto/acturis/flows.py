"""One function ("method") per Yes/No column of the test data sheet.

run_test_case() looks at the test's Excel row and calls the function for every
column set to Yes, in the same order as the columns in the sheet.
Inside any function, read a column with row["Column Name"], e.g. row["Policy Number"].
"""

import pytest

from acturis import app, locators, ui


# ==========================================================================
# Decides what to run from the Excel row
# ==========================================================================
def run_test_case(row):
    name = row["TestCaseName"]
    if "Yes" not in row.values():
        pytest.skip(f"No column is set to Yes for {name}, so there is nothing to run.")

    if is_yes(row, "Execution"):
        execution_steps(row)

    if is_yes(row, "Quote") and is_yes(row, "AuthorizeQuote"):
        locate_and_open_quote_by_insurer_quote_no(row["Insurer QuoteNumber"], name)
        authorize_quote(row)
    elif is_yes(row, "Quote"):
        quote_steps(row)
    elif is_yes(row, "AuthorizeQuote"):
        pytest.fail(
            f"AuthorizeQuote is Yes but Quote is No for {name}. "
            "Set Quote to Yes to locate and authorize the quote.",
            pytrace=False,
        )

    if is_yes(row, "Policy"):
        policy_steps(row)
    if is_yes(row, "MTA"):
        mta_steps(row)
    if is_yes(row, "Cancellation"):
        cancellation_steps(row)
    if is_yes(row, "Renewal Invite"):
        renewal_invite_steps(row)
    if is_yes(row, "Renewal"):
        renewal_steps(row)
    if is_yes(row, "Renewal Execution"):
        renewal_execution_steps(row)


def is_yes(row, column):
    if column not in row:
        raise AssertionError(
            f"Column '{column}' not found in the test data sheet. Columns: {', '.join(row)}"
        )
    return row[column] == "Yes"


def not_automated_yet(step):
    pytest.skip(f'The "{step}" step isn\'t automated yet. Add its steps in acturis/flows.py.')


# ==========================================================================
# Quote
# ==========================================================================
def locate_and_open_quote_by_insurer_quote_no(insurer_quote_no, test_name):
    if not insurer_quote_no:
        pytest.fail(f"Insurer QuoteNumber is empty for {test_name} in the test data sheet.", pytrace=False)
    if insurer_quote_no.upper() == "NA":
        pytest.fail(
            f"Insurer QuoteNumber is NA for {test_name}. Enter the real number to locate the quote.",
            pytrace=False,
        )

    # 1. UNDERWRITING tab > Locate Quote
    app.open_underwriting_tab()
    ui.click(locators.NAV_LOCATE_QUOTE)
    ui.wait_for(locators.LQ_CMB_SEARCH_ON)

    # 2. Search On: Insurer Quote No.
    ui.select_combo_item(locators.LQ_CMB_SEARCH_ON, locators.SEARCH_ON_INSURER_QUOTE_NO)

    # 3. Type the Insurer Quote No. from Excel and search
    ui.set_text(locators.LQ_TXT_SEARCH_VALUE, insurer_quote_no)
    ui.click(locators.LQ_BTN_SEARCH)

    # 4. Select the first result and open it
    ui.click(locators.LQ_FIRST_RESULT)
    ui.click(locators.LQ_BTN_OPEN_QUOTE)
    ui.screenshot(f"{test_name}_quote_opened")


def authorize_quote(row):
    # Runs after the quote is open (Quote = Yes and AuthorizeQuote = Yes).
    # TODO: inspect the open quote in FlaUInspect, add its locators to acturis/locators.py
    #       ("Quote screen" section), then replace the line below with the steps, e.g.
    #       ui.click(locators.QUOTE_BTN_AUTHORISE)
    not_automated_yet("Authorize Quote")


def quote_steps(row):
    # Runs when Quote = Yes and AuthorizeQuote = No.
    not_automated_yet("Quote")


# ==========================================================================
# Other columns: replace not_automated_yet(...) with the real steps
# ==========================================================================
def execution_steps(row):
    not_automated_yet("Execution")


def policy_steps(row):
    not_automated_yet("Policy")


def mta_steps(row):
    # Policy to adjust: row["Policy Number"]
    not_automated_yet("MTA")


def cancellation_steps(row):
    # Policy to cancel: row["Policy Number"]
    not_automated_yet("Cancellation")


def renewal_invite_steps(row):
    not_automated_yet("Renewal Invite")


def renewal_steps(row):
    not_automated_yet("Renewal")


def renewal_execution_steps(row):
    # Script to use: row["Renewal Execution Script"]
    not_automated_yet("Renewal Execution")
