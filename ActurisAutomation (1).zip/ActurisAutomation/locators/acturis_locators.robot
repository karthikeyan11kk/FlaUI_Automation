*** Settings ***
Documentation     All XPaths for Acturis Assistant, in one place (taken from FlaUInspect).
...               Add each new screen as its own section below.


*** Variables ***
# ==========================================================================
# Main window
# The title depends on the environment ("Acturis - UAT" here). Change it if yours differs.
# ==========================================================================
${MAIN_WINDOW}               /Window[@Name='Acturis - UAT']


# ==========================================================================
# Login screen
# ==========================================================================
${LOGIN_PANE}                ${MAIN_WINDOW}//Pane[@AutomationId='[LoginScreen]']

${LOGIN_TXT_USERNAME}        ${LOGIN_PANE}//Edit[@AutomationId='[LoginScreen][LogontoActuris][UserName]']
${LOGIN_TXT_PASSWORD}        ${LOGIN_PANE}//Edit[@AutomationId='[LoginScreen][LogontoActuris][Password]']

# The login button (its Name in Acturis is "Log On")
${LOGIN_BTN_LOGIN}           ${LOGIN_PANE}//Button[@AutomationId='[LoginScreen][LogontoActuris][Logon]']

# Radio buttons on the login screen
${LOGIN_RB_LOGON}            ${LOGIN_PANE}//RadioButton[@AutomationId='[LoginScreen][RadioButtons][LogontoActuris]']
${LOGIN_RB_CHANGE_PWD}       ${LOGIN_PANE}//RadioButton[@AutomationId='[LoginScreen][RadioButtons][ChangePassword]']
${LOGIN_RB_FORGOT_PWD}       ${LOGIN_PANE}//RadioButton[@AutomationId='[LoginScreen][RadioButtons][ResetAccount]']
${LOGIN_RB_TEMP_PWD}         ${LOGIN_PANE}//RadioButton[@AutomationId='[LoginScreen][RadioButtons][ActivateAccount]']


# ==========================================================================
# Next screen: paste its XPaths here after inspecting it in FlaUInspect
# ==========================================================================
