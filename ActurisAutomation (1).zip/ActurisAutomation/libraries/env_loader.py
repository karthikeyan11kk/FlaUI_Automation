"""Robot Framework variable file that loads KEY=value lines from a .env file.

Import it in a .robot file:
    Variables    ${CURDIR}/../libraries/env_loader.py    ${CURDIR}/../testdata/credentials.env

Every KEY=value line becomes the Robot variable ${KEY}.
- Lines starting with # are comments.
- Values are used exactly as written ($, #, \\ and = in passwords are fine).
- A Windows environment variable with the same name overrides the file,
  so a build server can supply the login without the file.

You don't need to edit this file.
"""

import os


def get_variables(env_file):
    if not os.path.isfile(env_file):
        raise FileNotFoundError(f"Test data file not found: {env_file}")

    variables = {}
    with open(env_file, encoding="utf-8-sig") as handle:
        for line_number, line in enumerate(handle, start=1):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                raise ValueError(f"{env_file}, line {line_number}: expected KEY=value, got '{line}'")
            key, value = line.split("=", 1)
            key, value = key.strip(), value.strip()
            # Optional surrounding quotes: KEY="value"
            if len(value) >= 2 and value[0] == value[-1] and value[0] in "'\"":
                value = value[1:-1]
            variables[key] = os.environ.get(key, value)
    return variables
