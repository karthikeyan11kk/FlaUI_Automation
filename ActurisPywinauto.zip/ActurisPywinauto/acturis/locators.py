"""All locators for Acturis Assistant, in one place (taken from FlaUInspect).

How a FlaUInspect tree line becomes a pywinauto locator:

    Edit "User Name" "[LoginScreen][LogontoActuris][UserName]"
     |       |                     |
     |       |                     +-- auto_id       (best: doesn't change)
     |       +------------------------ title         (the Name; can change with language)
     +-------------------------------- control_type

    -> {"auto_id": "[LoginScreen][LogontoActuris][UserName]", "control_type": "Edit"}

Each locator is a PATH: a list of steps from the main window down to the element.
Each step searches anywhere below the previous one (like // in an XPath), so
LOGIN_PANE + [...] means "inside the login pane, find ...".

tools/print_controls.py prints every control as child_window(title=..., auto_id=...,
control_type=...): copy those three values into a dict here.

Lines marked VERIFY are educated guesses: check them in FlaUInspect before the first run.
"""

# ==========================================================================
# Main window
# The title is "Acturis - UAT" on the login screen and grows after login,
# e.g. "Acturis - UAT - <user> - [Locate Task]". The regex ^ means "starts with".
# Change "Acturis - UAT" for other environments.
# ==========================================================================
MAIN_WINDOW = {"title_re": r"^Acturis - UAT", "control_type": "Window"}


# ==========================================================================
# Login screen
# ==========================================================================
LOGIN_PANE = [{"auto_id": "[LoginScreen]", "control_type": "Pane"}]
LOGIN_TXT_USERNAME = LOGIN_PANE + [{"auto_id": "[LoginScreen][LogontoActuris][UserName]", "control_type": "Edit"}]
LOGIN_TXT_PASSWORD = LOGIN_PANE + [{"auto_id": "[LoginScreen][LogontoActuris][Password]", "control_type": "Edit"}]
LOGIN_BTN_LOGIN = LOGIN_PANE + [{"auto_id": "[LoginScreen][LogontoActuris][Logon]", "control_type": "Button"}]  # "Log On"
LOGIN_RB_LOGON = LOGIN_PANE + [{"auto_id": "[LoginScreen][RadioButtons][LogontoActuris]", "control_type": "RadioButton"}]


# ==========================================================================
# Module tabs along the top (shown after login)
# The UNDERWRITING tab's auto_id is [PolicyAdmin].
# ==========================================================================
TABS_LIST = [{"auto_id": "[ModuleTabsObject]", "control_type": "List"}]
TAB_HOME = TABS_LIST + [{"auto_id": "[Home]", "control_type": "ListItem"}]
TAB_TASK_MANAGEMENT = TABS_LIST + [{"auto_id": "[TaskManagement]", "control_type": "ListItem"}]
TAB_UNDERWRITING = TABS_LIST + [{"auto_id": "[PolicyAdmin]", "control_type": "ListItem"}]
TAB_RENEWALS = TABS_LIST + [{"auto_id": "[Renewals]", "control_type": "ListItem"}]
TAB_BATCH_DOCUMENTS = TABS_LIST + [{"auto_id": "[BatchDocumentsModule]", "control_type": "ListItem"}]
TAB_AUTOMATION = TABS_LIST + [{"auto_id": "[Automation]", "control_type": "ListItem"}]
TAB_REPORTING = TABS_LIST + [{"auto_id": "[Reporting]", "control_type": "ListItem"}]
TAB_CONFIGURATION = TABS_LIST + [{"auto_id": "[Config]", "control_type": "ListItem"}]
BTN_LOG_OUT = [{"auto_id": "[LogoutObject]", "control_type": "SplitButton"}]


# ==========================================================================
# UNDERWRITING > left "Options" pane > "Search" list
# The "Locate Quote" list item and the Locate Quote screen share the auto_id
# [SearchLocateQuote], so control_type (ListItem vs Pane) tells them apart.
# ==========================================================================
NAV_SEARCH_LIST = [{"auto_id": "[ContactsSearchFrame]", "control_type": "List"}]
NAV_LOCATE_CONTACT = NAV_SEARCH_LIST + [{"auto_id": "[SearchLocateContact]", "control_type": "ListItem"}]
NAV_LOCATE_RFQ = NAV_SEARCH_LIST + [{"auto_id": "[SearchLocateRFQ]", "control_type": "ListItem"}]
NAV_LOCATE_QUOTE = NAV_SEARCH_LIST + [{"auto_id": "[SearchLocateQuote]", "control_type": "ListItem"}]
NAV_LOCATE_POLICY = NAV_SEARCH_LIST + [{"auto_id": "[SearchLocatePolicy]", "control_type": "ListItem"}]
NAV_LOCATE_CLAIM = NAV_SEARCH_LIST + [{"auto_id": "[SearchLocateClaim]", "control_type": "ListItem"}]


# ==========================================================================
# Locate Quote screen
# ==========================================================================
LQ_PANE = [{"auto_id": "[SearchLocateQuote]", "control_type": "Pane"}]
LQ_CMB_SEARCH_ON = LQ_PANE + [{"auto_id": "[SearchLocateQuote][MainSearchCriteria][SearchOn]", "control_type": "ComboBox"}]
# The search box's Name follows the "Search On" choice (e.g. "Quote Ref."), so use its auto_id
LQ_TXT_SEARCH_VALUE = LQ_PANE + [{"auto_id": "[SearchLocateQuote][MainSearchCriteria][SearchOnValue]", "control_type": "Edit"}]
LQ_BTN_CANCEL = LQ_PANE + [{"auto_id": "[SearchLocateQuote][LocateQuoteBar][CancelScreen]", "control_type": "Button"}]

# VERIFY: these three weren't in your screenshots, so they are found by title or control_type.
# found_index=0 takes the first match. Replace them with the auto_ids FlaUInspect shows.
LQ_BTN_SEARCH = LQ_PANE + [{"title": "Search", "control_type": "Button", "found_index": 0}]
LQ_FIRST_RESULT = LQ_PANE + [{"control_type": "DataItem", "found_index": 0}]
LQ_BTN_OPEN_QUOTE = LQ_PANE + [{"title": "Open Quote", "control_type": "Button", "found_index": 0}]

# Items in the "Search On" drop-down. Their Names end with a full stop.
SEARCH_ON_INSURER_QUOTE_NO = "Insurer Quote No."
SEARCH_ON_QUOTE_REF = "Quote Ref."
SEARCH_ON_INSURER_POLICY_NO = "Insurer Policy No."


# ==========================================================================
# Quote screen (after Open Quote): add the Authorize button etc. here
# ==========================================================================
