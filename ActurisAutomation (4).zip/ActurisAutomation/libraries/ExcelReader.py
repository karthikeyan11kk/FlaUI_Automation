"""Reads one test case row from an Excel workbook (.xls or .xlsx) for Robot Framework.

Usage:
    Library    ExcelReader.py
    &{data}=    Get Test Data    path/to/TestData.xls    Execution    TC01_Execution_Premium
    Log    ${data}[Product]

Row 1 of the sheet holds the column headers. The TestCaseName column (by default)
identifies each row. Every value comes back as text:
- numbers lose a trailing .0 (12345.0 -> "12345")
- dates become dd/mm/yyyy
- yes / YES / No are tidied to "Yes" / "No", so the .robot files can compare with 'Yes'
- empty cells become ""

You don't need to edit this file.
"""

import datetime
import os

from robot.api.deco import keyword, library


@library(scope="GLOBAL", auto_keywords=False)
class ExcelReader:

    @keyword("Get Test Data")
    def get_test_data(self, file_path, sheet_name, test_case_name, key_column="TestCaseName"):
        """Returns the row whose ``key_column`` equals ``test_case_name`` as a dictionary
        keyed by the column headers."""
        if not os.path.isfile(file_path):
            raise AssertionError(f"Test data file not found: {file_path}")

        extension = os.path.splitext(file_path)[1].lower()
        if extension == ".xls":
            rows = self._read_xls(file_path, sheet_name)
        elif extension in (".xlsx", ".xlsm"):
            rows = self._read_xlsx(file_path, sheet_name)
        else:
            raise AssertionError(f"Unsupported test data file type '{extension}'. Use .xls or .xlsx.")

        if not rows:
            raise AssertionError(f"Sheet '{sheet_name}' in {file_path} is empty.")
        headers = rows[0]
        if key_column not in headers:
            raise AssertionError(
                f"Column '{key_column}' not found in sheet '{sheet_name}'. "
                f"Columns: {', '.join(h for h in headers if h)}"
            )
        key_index = headers.index(key_column)

        wanted = str(test_case_name).strip()
        for row in rows[1:]:
            if key_index < len(row) and row[key_index] == wanted:
                return {
                    header: (row[i] if i < len(row) else "")
                    for i, header in enumerate(headers)
                    if header
                }
        raise AssertionError(
            f"No row with {key_column} = '{wanted}' in sheet '{sheet_name}' of {file_path}. "
            f"The test name must match the {key_column} column exactly."
        )

    # ------------------------------------------------------------------ readers
    def _read_xls(self, file_path, sheet_name):
        try:
            import xlrd
        except ImportError:
            raise AssertionError("Reading .xls files needs xlrd. Run: pip install xlrd") from None

        book = xlrd.open_workbook(file_path)
        if sheet_name not in book.sheet_names():
            raise AssertionError(
                f"Sheet '{sheet_name}' not found in {file_path}. "
                f"Available sheets: {', '.join(book.sheet_names())}"
            )
        sheet = book.sheet_by_name(sheet_name)

        def cell_text(cell):
            if cell.ctype == xlrd.XL_CELL_DATE:
                return self._to_text(xlrd.xldate.xldate_as_datetime(cell.value, book.datemode))
            if cell.ctype == xlrd.XL_CELL_BOOLEAN:
                return self._to_text(bool(cell.value))
            return self._to_text(cell.value)

        return [[cell_text(cell) for cell in sheet.row(r)] for r in range(sheet.nrows)]

    def _read_xlsx(self, file_path, sheet_name):
        try:
            from openpyxl import load_workbook
        except ImportError:
            raise AssertionError("Reading .xlsx files needs openpyxl. Run: pip install openpyxl") from None

        workbook = load_workbook(file_path, read_only=True, data_only=True)
        try:
            if sheet_name not in workbook.sheetnames:
                raise AssertionError(
                    f"Sheet '{sheet_name}' not found in {file_path}. "
                    f"Available sheets: {', '.join(workbook.sheetnames)}"
                )
            return [
                [self._to_text(value) for value in row]
                for row in workbook[sheet_name].iter_rows(values_only=True)
            ]
        finally:
            workbook.close()

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _to_text(value):
        if value is None:
            return ""
        if isinstance(value, (datetime.datetime, datetime.date)):
            return value.strftime("%d/%m/%Y")
        if isinstance(value, float) and value.is_integer():
            value = int(value)
        text = str(value).strip()
        if text.lower() == "yes":
            return "Yes"
        if text.lower() == "no":
            return "No"
        return text
