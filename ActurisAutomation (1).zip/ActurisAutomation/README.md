# Acturis Assistant automation (FlaUI + Robot Framework)

```
ActurisAutomation/
├── locators/
│   └── acturis_locators.robot   ← all XPaths
├── testdata/
│   └── credentials.env          ← user name and password
├── libraries/
│   └── env_loader.py            ← reads credentials.env (no need to edit)
├── tests/
│   └── login_tests.robot        ← test cases
├── run_tests.bat                ← double-click to run
└── requirements.txt
```

## 1. Install (once)

```
pip install -r requirements.txt
```

## 2. Add your login

Open `testdata\credentials.env` and fill in the values after `=`:

```
ACTURIS_USERNAME=your.user
ACTURIS_PASSWORD=your.password
```

No quotes are needed, and special characters such as `$ # \ =` are fine.

## 3. Run

Close Acturis if it is open, then double-click `run_tests.bat`, or run this in a terminal in this folder:

```
robot --outputdir results tests
```

Open `results\log.html` to see each step. Leave the mouse and keyboard alone while it runs.

## Adding more steps

1. Inspect the next screen in FlaUInspect.
2. Add its XPaths to `locators\acturis_locators.robot`.
3. Use them in `tests\login_tests.robot` after `Click    ${LOGIN_BTN_LOGIN}`.

More test data (a client name, a policy number) can go in `credentials.env` as `KEY=value` and is then available as `${KEY}`.
