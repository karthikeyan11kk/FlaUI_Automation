*** Settings ***
Documentation     One keyword ("method") per Yes/No column of the test data sheet.
...               Run Test Case From Excel reads the current test's row and calls the keyword for
...               every column set to Yes, in the same order as the columns in the sheet.
Resource          common.robot


*** Keywords ***
# ==========================================================================
# Decides what to run from the Excel row
# ==========================================================================
Run Test Case From Excel
    &{data}=    Get Test Data    ${TESTDATA_FILE}    ${TESTDATA_SHEET}    ${TEST NAME}
    Skip If    'Yes' not in $data.values()    No column is set to Yes for ${TEST NAME}, so there is nothing to run.

    IF    $data['Execution'] == 'Yes'    Execution Steps    ${data}

    IF    $data['Quote'] == 'Yes' and $data['AuthorizeQuote'] == 'Yes'
        Locate And Open Quote By Insurer Quote No    ${data}[Insurer QuoteNumber]
        Authorize Quote    ${data}
    ELSE IF    $data['Quote'] == 'Yes'
        Quote Steps    ${data}
    ELSE IF    $data['AuthorizeQuote'] == 'Yes'
        Fail    AuthorizeQuote is Yes but Quote is No for ${TEST NAME}. Set Quote to Yes to locate and authorize the quote.
    END

    IF    $data['Policy'] == 'Yes'               Policy Steps               ${data}
    IF    $data['MTA'] == 'Yes'                  MTA Steps                  ${data}
    IF    $data['Cancellation'] == 'Yes'         Cancellation Steps         ${data}
    IF    $data['Renewal Invite'] == 'Yes'       Renewal Invite Steps       ${data}
    IF    $data['Renewal'] == 'Yes'              Renewal Steps              ${data}
    IF    $data['Renewal Execution'] == 'Yes'    Renewal Execution Steps    ${data}


# ==========================================================================
# Quote
# ==========================================================================
Locate And Open Quote By Insurer Quote No
    [Arguments]    ${insurer_quote_no}
    Should Not Be Empty    ${insurer_quote_no}
    ...    msg=Insurer QuoteNumber is empty for ${TEST NAME} in the test data sheet.
    Should Not Be Equal As Strings    ${insurer_quote_no}    NA    ignore_case=True    values=False
    ...    msg=Insurer QuoteNumber is NA for ${TEST NAME}. Enter the real number to locate the quote.

    # 1. Open the Locate Quote screen from the Search list
    Click    ${NAV_LOCATE_QUOTE}
    Wait Until Keyword Succeeds    ${SCREEN_TIMEOUT}    1s    Element Should Exist    ${LQ_CMB_SEARCH_ON}

    # 2. Search On: Insurer Quote No.
    Select Combobox Item By Name    ${LQ_CMB_SEARCH_ON}    ${SEARCH_ON_INSURER_QUOTE_NO}

    # 3. Type the Insurer Quote No. from Excel and search
    Set Text To Textbox    ${LQ_TXT_SEARCH_VALUE}    ${insurer_quote_no}
    Click    ${LQ_BTN_SEARCH}

    # 4. Select the first result and open it
    Wait Until Keyword Succeeds    ${SCREEN_TIMEOUT}    1s    Element Should Exist    ${LQ_FIRST_RESULT}
    Click    ${LQ_FIRST_RESULT}
    Click    ${LQ_BTN_OPEN_QUOTE}
    Take Screenshot

Authorize Quote
    [Arguments]    ${data}
    # Runs after the quote is open (Quote = Yes and AuthorizeQuote = Yes).
    # TODO: inspect the open quote in FlaUInspect, add its XPaths to locators/acturis_locators.robot
    #       ("Quote screen" section), then replace the line below with the steps, e.g.
    #       Click    ${QUOTE_BTN_AUTHORISE}
    Not Automated Yet    Authorize Quote

Quote Steps
    [Arguments]    ${data}
    # Runs when Quote = Yes and AuthorizeQuote = No.
    Not Automated Yet    Quote


# ==========================================================================
# Other columns: replace "Not Automated Yet" with the real steps
# Read any column of the row with ${data}[Column Name], e.g. ${data}[Policy Number]
# ==========================================================================
Execution Steps
    [Arguments]    ${data}
    Not Automated Yet    Execution

Policy Steps
    [Arguments]    ${data}
    Not Automated Yet    Policy

MTA Steps
    [Arguments]    ${data}
    # Policy to adjust: ${data}[Policy Number]
    Not Automated Yet    MTA

Cancellation Steps
    [Arguments]    ${data}
    # Policy to cancel: ${data}[Policy Number]
    Not Automated Yet    Cancellation

Renewal Invite Steps
    [Arguments]    ${data}
    Not Automated Yet    Renewal Invite

Renewal Steps
    [Arguments]    ${data}
    Not Automated Yet    Renewal

Renewal Execution Steps
    [Arguments]    ${data}
    # Script to use: ${data}[Renewal Execution Script]
    Not Automated Yet    Renewal Execution
