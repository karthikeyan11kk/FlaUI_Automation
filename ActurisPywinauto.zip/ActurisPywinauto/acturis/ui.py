"""Small helpers on top of pywinauto, so the flows read like plain steps.

Every function takes a locator from acturis/locators.py: a list of criteria dicts
chained from the Acturis main window down to the element. Failures raise an
AssertionError that names the locator, so the pytest report shows what wasn't found.
"""

import re
from datetime import datetime

from pywinauto import Desktop
from pywinauto.timings import TimeoutError as WaitTimeout

from acturis import config, locators


def main_window():
    """The Acturis main window, found by its title from the desktop.
    That works even if ActurisAssistant.exe hands over to another process."""
    return Desktop(backend="uia").window(**locators.MAIN_WINDOW)


def element(locator):
    """Builds the pywinauto search for a locator path (nothing is searched until it's used)."""
    spec = main_window()
    for criteria in locator:
        spec = spec.child_window(**criteria)
    return spec


def describe(locator):
    return " > ".join(
        ", ".join(f"{key}={value!r}" for key, value in criteria.items()) for criteria in locator
    )


def wait_for(locator, timeout=config.SCREEN_TIMEOUT, state="exists"):
    """Waits until the element is there (state can also be 'exists enabled', 'visible'...)."""
    try:
        return element(locator).wait(state, timeout=timeout, retry_interval=0.5)
    except WaitTimeout:
        raise AssertionError(f"Not found within {timeout}s: {describe(locator)}") from None


def wait_until_gone(locator, timeout=config.SCREEN_TIMEOUT):
    try:
        element(locator).wait_not("exists", timeout=timeout, retry_interval=0.5)
    except WaitTimeout:
        raise AssertionError(f"Still shown after {timeout}s: {describe(locator)}") from None


def exists(locator, timeout=0):
    return element(locator).exists(timeout=timeout)


def click(locator, timeout=config.SCREEN_TIMEOUT):
    """A real mouse click in the middle of the element."""
    wait_for(locator, timeout, state="exists enabled").click_input()


def set_text(locator, value, timeout=config.SCREEN_TIMEOUT):
    control = wait_for(locator, timeout, state="exists enabled")
    try:
        control.set_edit_text(value)
    except Exception:
        # Some fields (e.g. masked password boxes) refuse direct setting: type the text instead.
        control.click_input()
        control.type_keys("^a{BACKSPACE}", set_foreground=True)
        control.type_keys(_escape_keys(value), with_spaces=True, set_foreground=True)


def select_combo_item(locator, item_name, timeout=config.SCREEN_TIMEOUT):
    """Picks an item from a drop-down by its Name, e.g. 'Insurer Quote No.'."""
    combo = wait_for(locator, timeout, state="exists enabled")
    try:
        combo.select(item_name)
    except Exception:
        # Fallback: open the drop-down and click the item
        combo.click_input()
        click(locator + [{"title": item_name, "control_type": "ListItem"}], timeout=5)


def screenshot(name):
    """Saves a screenshot of all screens to results/screenshots and returns its path.
    A failed screenshot only prints a warning, so it never fails a test."""
    try:
        from PIL import ImageGrab

        config.SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r"[^\w.-]+", "_", name)
        path = config.SCREENSHOT_DIR / f"{datetime.now():%Y%m%d_%H%M%S}_{safe_name}.png"
        ImageGrab.grab(all_screens=True).save(path)
        return path
    except Exception as error:
        print(f"WARNING: screenshot '{name}' failed: {error}")
        return None


def _escape_keys(text):
    """type_keys treats + ^ % ~ ( ) { } as special keys; wrap them in {} to type them literally."""
    return re.sub(r"([+^%~(){}\[\]])", r"{\1}", text)
