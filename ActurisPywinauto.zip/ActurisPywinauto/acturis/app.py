"""Starting, logging in to and closing Acturis Assistant."""

import os

from pywinauto import Application

from acturis import config, locators, ui


def launch_and_log_in():
    username, password = config.get_credentials()

    if ui.main_window().exists(timeout=1):
        raise RuntimeError("Acturis is already open. Close it, then run the tests again.")

    # Quotes around the path because it contains spaces; start it from its own folder.
    Application(backend="uia").start(
        f'"{config.APP_PATH}"',
        work_dir=os.path.dirname(config.APP_PATH),
        wait_for_idle=False,
    )

    # The first start can be slow, so keep checking until the login screen appears.
    ui.wait_for(locators.LOGIN_PANE, timeout=config.STARTUP_TIMEOUT)
    # Uncomment if "Log On to Acturis" isn't selected by default:
    # ui.click(locators.LOGIN_RB_LOGON)
    ui.set_text(locators.LOGIN_TXT_USERNAME, username)
    ui.set_text(locators.LOGIN_TXT_PASSWORD, password)
    ui.click(locators.LOGIN_BTN_LOGIN)

    # Logged in once the login screen has closed and the module tabs are shown
    ui.wait_until_gone(locators.LOGIN_PANE, timeout=config.LOGIN_TIMEOUT)
    ui.wait_for(locators.TAB_UNDERWRITING, timeout=config.LOGIN_TIMEOUT)


def open_underwriting_tab():
    ui.click(locators.TAB_UNDERWRITING)
    # The tab is ready when its Search list (Locate Quote, Locate Policy...) is shown
    ui.wait_for(locators.NAV_LOCATE_QUOTE)


def return_to_start_screen():
    """Runs after every test so the next one starts from a clean screen."""
    # TODO: add the clicks that close an opened quote once you know them.
    try:
        if ui.exists(locators.LQ_BTN_CANCEL, timeout=1):
            ui.click(locators.LQ_BTN_CANCEL)
    except Exception as error:
        print(f"WARNING: couldn't return to the start screen: {error}")


def close_acturis():
    """Closes the main window; kills the process if it doesn't close within 15 seconds."""
    window = ui.main_window()
    if not window.exists(timeout=1):
        return
    process_id = window.wrapper_object().process_id()
    try:
        window.wrapper_object().close()
        window.wait_not("exists", timeout=15)
    except Exception:
        try:
            Application(backend="uia").connect(process=process_id).kill()
        except Exception as error:
            print(f"WARNING: couldn't close Acturis: {error}")
