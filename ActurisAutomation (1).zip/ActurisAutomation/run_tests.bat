@echo off
rem Runs all Acturis tests and puts log.html / report.html in the results folder.
cd /d "%~dp0"
robot --outputdir results tests
pause
