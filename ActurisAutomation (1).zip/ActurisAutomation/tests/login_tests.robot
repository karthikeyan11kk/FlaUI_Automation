*** Settings ***
Documentation     Acturis Assistant: log in with the user name and password from testdata/credentials.env.
Library           FlaUILibrary
Resource          ../locators/acturis_locators.robot
Variables         ${CURDIR}/../libraries/env_loader.py    ${CURDIR}/../testdata/credentials.env
Test Setup        Credentials Should Be Filled In
Test Teardown     Close Acturis


*** Variables ***
# Robot Framework treats "\" as an escape character, so every backslash must be doubled.
${APP_PATH}            C:\\Program Files (x86)\\Acturis\\Installation\\ActurisAssistant.exe
${STARTUP_TIMEOUT}     120s
${LOGIN_TIMEOUT}       60s


*** Test Cases ***
TC01 Login To Acturis
    Launch Acturis
    # Uncomment the next line if "Log On to Acturis" isn't selected by default
    # Select Radiobutton    ${LOGIN_RB_LOGON}
    Set Text To Textbox    ${LOGIN_TXT_USERNAME}    ${ACTURIS_USERNAME}
    Set Text To Textbox    ${LOGIN_TXT_PASSWORD}    ${ACTURIS_PASSWORD}
    Click                  ${LOGIN_BTN_LOGIN}
    Login Should Be Successful


*** Keywords ***
Credentials Should Be Filled In
    Should Not Be Empty    ${ACTURIS_USERNAME}    msg=ACTURIS_USERNAME is empty in testdata/credentials.env
    Should Not Be Empty    ${ACTURIS_PASSWORD}    msg=ACTURIS_PASSWORD is empty in testdata/credentials.env

Launch Acturis
    Launch Application    ${APP_PATH}
    # The first start can be slow, so keep checking until the login screen appears.
    Wait Until Keyword Succeeds    ${STARTUP_TIMEOUT}    3s    Element Should Exist    ${LOGIN_PANE}

Login Should Be Successful
    # After a successful login the login screen closes.
    Wait Until Keyword Succeeds    ${LOGIN_TIMEOUT}    2s    Element Should Not Exist    ${LOGIN_PANE}
    Take Screenshot

Close Acturis
    Run Keyword And Ignore Error    Close Application
