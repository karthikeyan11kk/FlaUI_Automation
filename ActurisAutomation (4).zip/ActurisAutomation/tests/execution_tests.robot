*** Settings ***
Documentation     Runs the test cases in testdata/TestData.xls, sheet "Execution".
...               Acturis is opened and logged in once, then each test reads its own row.
...               A test's name must match the TestCaseName column exactly.
...               To add a test case: add a row in Excel, then add the same name below.
Resource          ../resources/common.robot
Resource          ../resources/acturis_flows.robot
Suite Setup       Launch Acturis And Log In
Suite Teardown    Close Acturis
Test Teardown     Return To Start Screen


*** Test Cases ***
TC01_Execution_Premium
    Run Test Case From Excel

TC02_CapstoneString
    Run Test Case From Excel

TC03_Renewal_RC
    Run Test Case From Excel

TC04_Commission_Override
    Run Test Case From Excel

TC05_Endrosement
    Run Test Case From Excel

TC06_Execution_Premium
    Run Test Case From Excel
