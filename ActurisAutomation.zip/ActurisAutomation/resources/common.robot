*** Settings ***
Documentation     Shared settings and keywords for the Acturis Assistant tests.
Library           FlaUILibrary
Library           ${CURDIR}${/}..${/}libraries${/}ExcelReader.py
Resource          locators.robot


*** Variables ***
# Robot Framework treats "\" as an escape character, so every backslash must be doubled.
${APP_PATH}            C:\\Program Files (x86)\\Acturis\\Installation\\ActurisAssistant.exe

# Test data workbook. ${CURDIR} is this file's folder, so the path works from any working directory.
${TESTDATA_FILE}       ${CURDIR}${/}..${/}testdata${/}TestData.xlsx
${LOGIN_SHEET}         Login

${STARTUP_TIMEOUT}     120s
${LOGIN_TIMEOUT}       60s


*** Keywords ***
Launch Acturis
    ${pid}=    Launch Application    ${APP_PATH}
    Log    Started Acturis Assistant (PID ${pid})
    # The first start can be slow (updates and loading), so poll until the login screen appears.
    Wait Until Keyword Succeeds    ${STARTUP_TIMEOUT}    3s    Element Should Exist    ${LOGIN_PANE}

Log On With Test Data
    [Documentation]    Reads the row for ${test_case_id} from the Login sheet of TestData.xlsx
    ...                and logs on with its Username and Password.
    [Arguments]    ${test_case_id}
    # Turn logging off while the row is read, so the password is never written to log.html.
    ${old_level}=    Set Log Level    NONE
    &{data}=    Get Test Data    ${TESTDATA_FILE}    ${LOGIN_SHEET}    ${test_case_id}
    Set Log Level    ${old_level}
    Log On To Acturis With    ${data}[Username]    ${data}[Password]

Log On To Acturis With
    [Arguments]    ${username}    ${password}
    Should Not Be Empty    ${username}    msg=Username is empty in the test data file.
    Should Not Be Empty    ${password}    msg=Password is empty in the test data file.
    Select Radiobutton     ${LOGIN_RB_LOGON}
    Set Text To Textbox    ${LOGIN_TXT_USERNAME}    ${username}
    Set Text To Textbox    ${LOGIN_TXT_PASSWORD}    ${password}
    Click                  ${LOGIN_BTN_LOGON}

Login Should Succeed
    # A successful logon closes the login screen.
    Wait Until Keyword Succeeds    ${LOGIN_TIMEOUT}    2s    Element Should Not Exist    ${LOGIN_PANE}
    Take Screenshot

Close Acturis
    Run Keyword And Ignore Error    Close Application
