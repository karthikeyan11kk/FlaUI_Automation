# Acturis Assistant automation (FlaUI + Robot Framework)

```
ActurisAutomation/
├── locators/
│   └── acturis_locators.robot   ← all XPaths (login, Search list, Locate Quote)
├── testdata/
│   ├── credentials.env          ← user name and password
│   └── TestData.xls             ← test cases, sheet "Execution" (replace with your real file)
├── libraries/
│   ├── env_loader.py            ← reads credentials.env  (no need to edit)
│   └── ExcelReader.py           ← reads a row from .xls / .xlsx (no need to edit)
├── resources/
│   ├── common.robot             ← app path, test data path, login, close
│   └── acturis_flows.robot      ← one keyword ("method") per Yes/No column
├── tests/
│   └── execution_tests.robot    ← one test per Excel row
├── run_tests.bat
└── requirements.txt
```

## How a run works

1. **Suite Setup**: opens Acturis and logs in once (credentials.env).
2. Each test reads **its own row**: the test name must match the `TestCaseName` column.
3. For every column set to **Yes**, the matching keyword in `resources/acturis_flows.robot` runs,
   left to right in column order:

| Excel | Runs |
|---|---|
| Quote = Yes **and** AuthorizeQuote = Yes | `Locate And Open Quote By Insurer Quote No` (Locate Quote → Search On "Insurer Quote No." → type the number → Search → open the first result), then `Authorize Quote` |
| Quote = Yes only | `Quote Steps` |
| Execution, Policy, MTA, Cancellation, Renewal Invite, Renewal, Renewal Execution | `<Column> Steps` |

4. **Test Teardown**: returns to the start screen. **Suite Teardown**: closes Acturis.

Result meanings:
- **SKIP: No column is set to Yes**: that row has nothing to run.
- **SKIP: "X" step isn't automated yet**: write that keyword's steps (replace `Not Automated Yet`).
- **FAIL**: a real problem, such as an empty or NA Insurer QuoteNumber, or an element not found.

## Setup (once)

```
pip install -r requirements.txt
```

1. Put your user name and password in `testdata\credentials.env`.
2. Copy your real `TestData.xls` into `testdata\` (same name, sheet `Execution`), then save and close it.

## Run

Close Acturis, then double-click `run_tests.bat`, or:

```
robot --outputdir results tests
```

Run one test case only:

```
robot --outputdir results --test TC01_Execution_Premium tests
```

## Adding things

- **New Excel row**: add the same name as a test in `tests\execution_tests.robot`
  (2 lines: the name, then `    Run Test Case From Excel`).
- **Authorize steps**: inspect the open quote in FlaUInspect, add XPaths to the "Quote screen"
  section of the locators file, and put the clicks in `Authorize Quote`.
- **Any column's value** inside a keyword: `${data}[Policy Number]`, `${data}[Product]`, ...

## Check these locators first (marked VERIFY)

The Search button, the first result row and the Open Quote button weren't in the screenshots,
so they are found by Name / ControlType. If a test fails there, inspect them in FlaUInspect
and replace them with their AutomationIds.

If `Select Combobox Item By Name` can't pick "Insurer Quote No.", use two clicks instead:

```
Click    ${LQ_CMB_SEARCH_ON}
Click    ${LQ_CMB_SEARCH_ON}//ListItem[@Name='Insurer Quote No.']
```
