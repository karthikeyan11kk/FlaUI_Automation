*** Settings ***
Documentation     All XPaths for Acturis Assistant, in one place (taken from FlaUInspect).
...               Lines marked VERIFY are educated guesses: check them in FlaUInspect before the first run.


*** Variables ***
# ==========================================================================
# Main window
# starts-with() matches "Acturis - UAT" and also a longer title after login,
# e.g. "Acturis - UAT - <user>". Change "Acturis - UAT" for other environments.
# ==========================================================================
${MAIN_WINDOW}                   /Window[starts-with(@Name,'Acturis - UAT')]


# ==========================================================================
# Login screen
# ==========================================================================
${LOGIN_PANE}                    ${MAIN_WINDOW}//Pane[@AutomationId='[LoginScreen]']
${LOGIN_TXT_USERNAME}            ${LOGIN_PANE}//Edit[@AutomationId='[LoginScreen][LogontoActuris][UserName]']
${LOGIN_TXT_PASSWORD}            ${LOGIN_PANE}//Edit[@AutomationId='[LoginScreen][LogontoActuris][Password]']
${LOGIN_BTN_LOGIN}               ${LOGIN_PANE}//Button[@AutomationId='[LoginScreen][LogontoActuris][Logon]']
${LOGIN_RB_LOGON}                ${LOGIN_PANE}//RadioButton[@AutomationId='[LoginScreen][RadioButtons][LogontoActuris]']


# ==========================================================================
# Left "Options" pane > "Search" list (shown after login)
# The "Locate Quote" list item and the Locate Quote screen both have the AutomationId
# [SearchLocateQuote], so the ControlType (ListItem vs Pane) tells them apart.
# ==========================================================================
${NAV_SEARCH_LIST}               ${MAIN_WINDOW}//List[@AutomationId='[ContactsSearchFrame]']
${NAV_LOCATE_CONTACT}            ${NAV_SEARCH_LIST}/ListItem[@AutomationId='[SearchLocateContact]']
${NAV_LOCATE_RFQ}                ${NAV_SEARCH_LIST}/ListItem[@AutomationId='[SearchLocateRFQ]']
${NAV_LOCATE_QUOTE}              ${NAV_SEARCH_LIST}/ListItem[@AutomationId='[SearchLocateQuote]']
${NAV_LOCATE_POLICY}             ${NAV_SEARCH_LIST}/ListItem[@AutomationId='[SearchLocatePolicy]']
${NAV_LOCATE_CLAIM}              ${NAV_SEARCH_LIST}/ListItem[@AutomationId='[SearchLocateClaim]']


# ==========================================================================
# Locate Quote screen
# ==========================================================================
${LQ_PANE}                       ${MAIN_WINDOW}//Pane[@AutomationId='[SearchLocateQuote]']
${LQ_CMB_SEARCH_ON}              ${LQ_PANE}//ComboBox[@AutomationId='[SearchLocateQuote][MainSearchCriteria][SearchOn]']
# The search box's Name follows the "Search On" choice (e.g. "Quote Ref."), so use its AutomationId
${LQ_TXT_SEARCH_VALUE}           ${LQ_PANE}//Edit[@AutomationId='[SearchLocateQuote][MainSearchCriteria][SearchOnValue]']
${LQ_BTN_CANCEL}                 ${LQ_PANE}//Button[@AutomationId='[SearchLocateQuote][LocateQuoteBar][CancelScreen]']

# VERIFY: these three weren't in your screenshots, so they are found by Name or ControlType.
# Replace them with the AutomationIds FlaUInspect shows.
${LQ_BTN_SEARCH}                 ${LQ_PANE}//Button[@Name='Search']
${LQ_FIRST_RESULT}               (${LQ_PANE}//DataItem)[1]
${LQ_BTN_OPEN_QUOTE}             ${LQ_PANE}//Button[@Name='Open Quote']

# Items in the "Search On" drop-down. Their Names end with a full stop.
${SEARCH_ON_INSURER_QUOTE_NO}    Insurer Quote No.
${SEARCH_ON_QUOTE_REF}           Quote Ref.
${SEARCH_ON_INSURER_POLICY_NO}   Insurer Policy No.


# ==========================================================================
# Quote screen (after Open Quote): add the Authorize button etc. here
# ==========================================================================
