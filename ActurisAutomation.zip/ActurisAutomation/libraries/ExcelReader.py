"""Reads test data rows from an Excel workbook for Robot Framework.

Usage in Robot Framework:
    Library    ExcelReader.py
    &{data}=    Get Test Data    path/to/TestData.xlsx    Login    TC01
    Log    ${data}[Username]

The first row of the sheet must contain the column headers. One column
(default "TestCaseID") identifies each row. Every value comes back as text,
so numeric passwords such as 12345 are not turned into 12345.0.
"""

import os

from openpyxl import load_workbook
from robot.api.deco import keyword, library


@library(scope="GLOBAL", auto_keywords=False)
class ExcelReader:

    @keyword("Get Test Data")
    def get_test_data(self, file_path, sheet_name, test_case_id, key_column="TestCaseID"):
        """Returns the row whose ``key_column`` equals ``test_case_id`` as a dictionary.

        Dictionary keys are the column headers from the first row.
        Fails if the file, sheet, column or row cannot be found.
        """
        if not os.path.isfile(file_path):
            raise AssertionError(f"Test data file not found: {file_path}")

        workbook = load_workbook(file_path, read_only=True, data_only=True)
        try:
            if sheet_name not in workbook.sheetnames:
                raise AssertionError(
                    f"Sheet '{sheet_name}' not found in {file_path}. "
                    f"Available sheets: {', '.join(workbook.sheetnames)}"
                )
            rows = workbook[sheet_name].iter_rows(values_only=True)

            headers = [self._to_text(h) for h in next(rows, ())]
            if key_column not in headers:
                raise AssertionError(
                    f"Column '{key_column}' not found in sheet '{sheet_name}'. "
                    f"Columns: {', '.join(h for h in headers if h)}"
                )
            key_index = headers.index(key_column)

            wanted = str(test_case_id).strip()
            for row in rows:
                if key_index < len(row) and self._to_text(row[key_index]) == wanted:
                    return {
                        header: self._to_text(value)
                        for header, value in zip(headers, row)
                        if header
                    }

            raise AssertionError(
                f"No row with {key_column} = '{wanted}' in sheet '{sheet_name}' of {file_path}"
            )
        finally:
            workbook.close()

    @staticmethod
    def _to_text(value):
        if value is None:
            return ""
        if isinstance(value, float) and value.is_integer():
            value = int(value)
        return str(value).strip()
