*** Settings ***
Documentation     Settings and keywords shared by all Acturis tests: libraries, test data, login.
Library           FlaUILibrary
Library           ${CURDIR}/../libraries/ExcelReader.py
Variables         ${CURDIR}/../libraries/env_loader.py    ${CURDIR}/../testdata/credentials.env
Resource          ../locators/acturis_locators.robot


*** Variables ***
# Robot Framework treats "\" as an escape character, so every backslash must be doubled.
${APP_PATH}             C:\\Program Files (x86)\\Acturis\\Installation\\ActurisAssistant.exe

# Test data: one row per test case, matched on the TestCaseName column (.xls or .xlsx)
${TESTDATA_FILE}        ${CURDIR}${/}..${/}testdata${/}TestData.xls
${TESTDATA_SHEET}       Execution

${STARTUP_TIMEOUT}      120s
${LOGIN_TIMEOUT}        60s
${SCREEN_TIMEOUT}       30s


*** Keywords ***
Launch Acturis And Log In
    Should Not Be Empty    ${ACTURIS_USERNAME}    msg=ACTURIS_USERNAME is empty in testdata/credentials.env
    Should Not Be Empty    ${ACTURIS_PASSWORD}    msg=ACTURIS_PASSWORD is empty in testdata/credentials.env
    Launch Application    ${APP_PATH}
    Wait Until Keyword Succeeds    ${STARTUP_TIMEOUT}    3s    Element Should Exist    ${LOGIN_PANE}
    Set Text To Textbox    ${LOGIN_TXT_USERNAME}    ${ACTURIS_USERNAME}
    Set Text To Textbox    ${LOGIN_TXT_PASSWORD}    ${ACTURIS_PASSWORD}
    Click                  ${LOGIN_BTN_LOGIN}
    # Logged in once the login screen has closed and the Search options are shown
    Wait Until Keyword Succeeds    ${LOGIN_TIMEOUT}    2s    Element Should Not Exist    ${LOGIN_PANE}
    Wait Until Keyword Succeeds    ${LOGIN_TIMEOUT}    2s    Element Should Exist    ${NAV_LOCATE_QUOTE}

Return To Start Screen
    [Documentation]    Runs after every test so the next one starts from a clean screen.
    # TODO: add the clicks that close an opened quote once you know them.
    Run Keyword And Ignore Error    Click    ${LQ_BTN_CANCEL}

Close Acturis
    Run Keyword And Ignore Error    Close Application

Not Automated Yet
    [Arguments]    ${step}
    Skip    The "${step}" step isn't automated yet. Add its clicks in resources/acturis_flows.robot.
