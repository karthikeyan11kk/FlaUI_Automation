*** Settings ***
Documentation     Object repository: every XPath used in the Acturis tests lives in this file.
...               Locators were taken from FlaUInspect (Name / AutomationId).
...               Add each new screen as its own section below, and name variables SCREEN_TYPE_NAME.


*** Variables ***
# ==========================================================================
# Main window
# The title depends on the environment ("Acturis - UAT" here). Change it for other environments.
# ==========================================================================
${MAIN_WINDOW}               /Window[@Name='Acturis - UAT']


# ==========================================================================
# Login screen
# ==========================================================================
${LOGIN_PANE}                ${MAIN_WINDOW}//Pane[@AutomationId='[LoginScreen]']

# Radio buttons
${LOGIN_RB_LOGON}            ${LOGIN_PANE}//RadioButton[@AutomationId='[LoginScreen][RadioButtons][LogontoActuris]']
${LOGIN_RB_CHANGE_PWD}       ${LOGIN_PANE}//RadioButton[@AutomationId='[LoginScreen][RadioButtons][ChangePassword]']
${LOGIN_RB_FORGOT_PWD}       ${LOGIN_PANE}//RadioButton[@AutomationId='[LoginScreen][RadioButtons][ResetAccount]']
${LOGIN_RB_TEMP_PWD}         ${LOGIN_PANE}//RadioButton[@AutomationId='[LoginScreen][RadioButtons][ActivateAccount]']

# Text boxes
${LOGIN_TXT_USERNAME}        ${LOGIN_PANE}//Edit[@AutomationId='[LoginScreen][LogontoActuris][UserName]']
${LOGIN_TXT_PASSWORD}        ${LOGIN_PANE}//Edit[@AutomationId='[LoginScreen][LogontoActuris][Password]']

# Buttons
${LOGIN_BTN_LOGON}           ${LOGIN_PANE}//Button[@AutomationId='[LoginScreen][LogontoActuris][Logon]']


# ==========================================================================
# Next screen (add locators here after inspecting it in FlaUInspect)
# ==========================================================================
