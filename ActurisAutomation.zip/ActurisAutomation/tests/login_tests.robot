*** Settings ***
Documentation     Acturis Assistant: login tests.
...               Test data (Username, Password) comes from testdata/TestData.xlsx, sheet "Login".
...               Each test passes its TestCaseID, which must match a row in that sheet.
Resource          ../resources/common.robot
Test Teardown     Close Acturis


*** Test Cases ***
TC01 Log On With Valid Credentials
    [Tags]    login    smoke
    Launch Acturis
    Log On With Test Data    TC01
    Login Should Succeed
